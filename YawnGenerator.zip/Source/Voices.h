/*
  ==============================================================================

    Voice.h
    Created: 14 Dec 2018 1:12:08am
    Author:  matth

  ==============================================================================
*/

#pragma once

class Voice {

public:
	double time;
	double value;
	Voice(){
		time = 0.0;
		value = 0.0;
	};
};
